# Clear local storage (example: delete a directory)
$localStoragePath = "path/to/local/storage"
if (Test-Path $localStoragePath) {
    Remove-Item -Recurse -Force $localStoragePath
    Write-Output "Local storage cleaned successfully!"
}

# Clear session storage (example: delete a directory)
$sessionStoragePath = "path/to/session/storage"
if (Test-Path $sessionStoragePath) {
    Remove-Item -Recurse -Force $sessionStoragePath
    Write-Output "Session storage cleaned successfully!"
}

# Clear cookies (example: delete a file)
$cookiesPath = "path/to/cookies/file"
if (Test-Path $cookiesPath) {
    Remove-Item -Force $cookiesPath
    Write-Output "Cookies cleaned successfully!"
}

# Block ads by modifying the hosts file
$hostsPath = "C:\Windows\System32\drivers\etc\hosts"
$adServers = @(
    "adserver.example.com",
    "ads.example.com"
)
foreach ($adServer in $adServers) {
    Add-Content -Path $hostsPath -Value "127.0.0.1 $adServer"
}
Write-Output "Ads blocked successfully!"
