import java.util.prefs.Preferences;

public class StorageCleaner {
    public static void main(String[] args) {
        // Clear preferences (local storage equivalent)
        Preferences prefs = Preferences.userRoot();
        try {
            prefs.clear();
            System.out.println("Storage cleaned successfully!");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
