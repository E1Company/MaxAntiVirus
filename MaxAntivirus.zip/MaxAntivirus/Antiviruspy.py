import os
import shutil
import requests

def clean_storage():
    # Clear local storage (example: delete a directory)
    local_storage_path = 'path/to/local/storage'
    if os.path.exists(local_storage_path):
        shutil.rmtree(local_storage_path)
        print("Local storage cleaned successfully!")

    # Clear session storage (example: delete a directory)
    session_storage_path = 'path/to/session/storage'
    if os.path.exists(session_storage_path):
        shutil.rmtree(session_storage_path)
        print("Session storage cleaned successfully!")

    # Clear cookies (example: delete a file)
    cookies_path = 'path/to/cookies/file'
    if os.path.exists(cookies_path):
        os.remove(cookies_path)
        print("Cookies cleaned successfully!")

def block_ads():
    # Example of blocking ads by modifying the hosts file
    hosts_path = '/etc/hosts'
    ad_servers = [
        'adserver.example.com',
        'ads.example.com'
    ]
    with open(hosts_path, 'a') as hosts_file:
        for ad_server in ad_servers:
            hosts_file.write(f'127.0.0.1 {ad_server}\n')
    print("Ads blocked successfully!")

if __name__ == "__main__":
    clean_storage()
    block_ads()
